﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HtmlAgilityPack;
using ScrapySharp.Extensions;
using ScrapySharp.Network;
using System.Net;
using System.IO;
using System.Net.Http;
using CsvHelper;
using System.Globalization;

namespace CurrencyScraper
{
    class Program
    {
        static void Main(string[] args)
        {
            var ddown = GetDropdownItems("https://srh.bankofchina.com/search/whpj/searchen.jsp");
            GetTableData(ddown);
        }
        //exports the data from the list into a csv file
        static void exportCurrencyToCSV(List<CurrencyDetails> lstCurrencyDetails, string currency, string dateStart, string dateEnd, string folder)
        {
            string user = Environment.UserName;
            using (var writer = new StreamWriter($@"/Users/{user}/Desktop/{folder}/{currency}_{dateStart}_{dateEnd}.csv"))
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                csv.WriteRecords(lstCurrencyDetails);
            }
        }
        //Scrapes the data from the table
        static List<CurrencyDetails> GetTableData(List<string> items)
        {
            string s = "https://srh.bankofchina.com/search/whpj/searchen.jsp";
            string endDate = DateTime.Now.ToString("yyyy-MM-dd");
            string beginDate = DateTime.Now.AddDays(-2).ToString("yyyy-MM-dd");

            var folder = CreateFolder();

            var lstCurrencyDetails = new List<CurrencyDetails>();

            foreach (var item in items)
            {
                int page = 1;
                //Does the search for the current currency in the foreach
                var search = "erectDate=" + beginDate + "&nothing=" + endDate + "&pjname=" + item + "&page=" + page;

                    var rslt = HttpPostRequest(s, search);

                    var htmlNode = rslt.ToHtmlNode();
                
                var currencyDetails = new CurrencyDetails();
                
                    for (int i = 2; i <= 21; i++) //Goes through table data and stores it in a list
                {
                        var name = htmlNode.OwnerDocument.DocumentNode.SelectSingleNode("/html/body/table[2]/tr[" + i + "]/td[1]");
                        if (name != null)
                            currencyDetails.currency = name.InnerText;

                        var bRate = htmlNode.OwnerDocument.DocumentNode.SelectSingleNode("/html/body/table[2]/tr[" + i + "]/td[2]");
                        if (bRate != null)
                            currencyDetails.buyingRate = bRate.InnerText;

                        var cashbRate = htmlNode.OwnerDocument.DocumentNode.SelectSingleNode("/html/body/table[2]/tr[" + i + "]/td[3]");
                        if (cashbRate != null)
                            currencyDetails.cashBuyingRate = cashbRate.InnerText;

                        var sRate = htmlNode.OwnerDocument.DocumentNode.SelectSingleNode("/html/body/table[2]/tr[" + i + "]/td[4]");
                        if (sRate != null)
                            currencyDetails.sellingRate = sRate.InnerText;

                        var cashsRate = htmlNode.OwnerDocument.DocumentNode.SelectSingleNode("/html/body/table[2]/tr[" + i + "]/td[5]");
                        if (cashsRate != null)
                            currencyDetails.cashSellingRate = cashsRate.InnerText;

                        var mRate = htmlNode.OwnerDocument.DocumentNode.SelectSingleNode("/html/body/table[2]/tr[" + i + "]/td[6]");
                        if (mRate != null)
                            currencyDetails.middleRate = mRate.InnerText;

                        var t = htmlNode.OwnerDocument.DocumentNode.SelectSingleNode("/html/body/table[2]/tr[" + i + "]/td[7]");
                        if (t != null)
                            currencyDetails.time = t.InnerText;


                        lstCurrencyDetails.Add(currencyDetails);
                    }
                exportCurrencyToCSV(lstCurrencyDetails, item, beginDate, endDate, folder);
                lstCurrencyDetails.Clear();
            }
            
            return lstCurrencyDetails;
        }
        //Creates a folder on the Desktop and names it based off of the user input
        public static string CreateFolder()
        {
            Console.WriteLine("A folder for the generated files will be created on the Desktop");
            Console.WriteLine("Name of the folder:");
            var name = Console.ReadLine();
            string user = Environment.UserName;
            var path = "C:\\Users\\" + user + "\\Desktop\\";
            var folder = Path.Combine(path, name);

            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            return name;
        }
        //returns the html of the page
        static HtmlNode GetHtml(string url)
        {
            ScrapingBrowser _scrapingBrowser = new ScrapingBrowser();
            WebPage webpage = _scrapingBrowser.NavigateToPage(new Uri(url));
            return webpage.Html;
        }
        //fills the list with all the items from the currency dropdown 
        static List<string> GetDropdownItems(string url)
        {
            var DropDownItems = new List<string>();

            var html = GetHtml(url);

            var options = html.CssSelect("option");

            foreach (var option in options)
            {
                if(option.NextSibling.InnerText.Length == 3)
                    DropDownItems.Add(option.NextSibling.InnerText);
            }

            return DropDownItems;
        }
        //does the search based on the dates and currency
        public static string HttpPostRequest(string url, string search)
        {
            
            WebRequest request = WebRequest.Create(url);
            request.ContentType = "application/x-www-form-urlencoded";
            request.Method = "POST";
            byte[] bytes = Encoding.ASCII.GetBytes(search);
            request.ContentLength = bytes.Length;
            Stream stream = request.GetRequestStream();
            stream.Write(bytes, 0, bytes.Length);
            stream.Close();
            WebResponse response = request.GetResponse();
            if (response == null) return null;

            StreamReader sr = new StreamReader(response.GetResponseStream());
            return sr.ReadToEnd().Trim();
        }
        //class for the list that contains the scraped data
        public class CurrencyDetails
        {
            public string currency { get; set; }
            public string buyingRate { get; set; }
            public string cashBuyingRate { get; set; }
            public string sellingRate { get; set; }
            public string cashSellingRate { get; set; }
            public string middleRate { get; set; }
            public string time { get; set; }
        }
    }
}
